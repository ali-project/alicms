(function() {
    CKEDITOR.dialog.add("multiimg",
        function(a) {
            return {
                title: "批量上传图片",
                minWidth: "660px",
                minHeight:"400px",
                contents: [{
                    id: "tab1",
                    label: "",
                    title: "",
                    expand: true,
                    width: "420px",
                    height: "300px",
                    padding: 0,
                    elements: [{
                        type: "html",
                        style: "width:800px;height:400px",
                        html: '<iframe id="uploadFrame" src="/index.php?m=alicms&f=qiniu&v=upload&p=&_su=wuzhicms" frameborder="0"></iframe>'
                    }]
                }],
                onOk: function() {
                    // 拿到對象,這個在iframe里定義
                    var num = window.returnimg;
 
                    //点击确定按钮后的操作
                    a.insertHtml("<br>"+num+"<br>");
                },
                onShow: function () {
                    document.getElementById("uploadFrame").setAttribute("src","/index.php?m=alicms&f=qiniu&v=upload&p=&_su=wuzhicms");
                }
            }
        })
})();